// Importaciones
const WebSocket = require('ws');
const http = require('http');

// Creamos una instacia del servidor HTTP (Web)
const server = http.createServer();
// Creamos y levantamos un servidor de WebSockets a partir del servidor HTTP
const wss = new WebSocket.Server({ server });
// Escuchamos los eventos de conexión
wss.on('connection', function connection(ws) {
    function AsignarEspacios(){
        const espacios= [{spaceId: '01', state: 'free'}, {spaceId: '02', state: 'free'},{spaceId: '03', state: 'free'}];
        setTimeout(()=>{
            const espacios= [{spaceId: '01', state: 'occupied'}, {spaceId: '02', state: 'occupied'},{spaceId: '03', state: 'occupied'}];
            return espacios;
        }, 5000)
        return espacios;
    }
    // Escuchamos los mensajes entrantes
    wss.on('message', function incoming(data) {
        ws.send(AsignarEspacios())
    });
});

// Levantamos servidor HTTP
server.listen(8080);
console.log('Servidor funcionando. Utiliza ws://localhost:8080 para conectar.')
