package com.dailycodebuffer.websocket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebsocketApplicationTests {

	@Test
	void contextLoads() {
	}

}
